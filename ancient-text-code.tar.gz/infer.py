#!/usr/bin/env python3
"""
古文字识别比赛 - 推断脚本
第一阶段：用PaddleOCR预训练模型直接推理
第二阶段：可替换为微调后的模型

输入：/saisdata/13/eval/images/*.png
输出：/saisresult/prediction.json
"""

import os
import sys
import json
import glob
import time
import numpy as np
from PIL import Image
from tqdm import tqdm

def run_inference(input_dir, output_file, use_finetuned=False):
    """
    主推断函数
    """
    # 延时导入，确保PaddleOCR环境就绪
    from paddleocr import PaddleOCR
    
    # PaddleOCR配置
    # 检测模型：使用轻量级中文检测模型
    # 识别模型：使用轻量级中文识别模型
    ocr_args = {
        'use_angle_cls': False,  # 不需要文字方向分类
        'lang': 'ch',            # 中文
        'show_log': False,       # 不显示日志
        'use_gpu': True,         # 使用GPU
        'gpu_mem': 8000,         # GPU内存限制
        'det_db_thresh': 0.3,    # 检测阈值，调低以检测模糊文字
        'det_db_box_thresh': 0.5,
        'rec_batch_num': 6,      # 识别批大小
    }
    
    # 如果使用微调模型，替换模型路径
    if use_finetuned:
        finetuned_dir = '/workspace/finetuned_models'
        det_model_dir = os.path.join(finetuned_dir, 'det')
        rec_model_dir = os.path.join(finetuned_dir, 'rec')
        if os.path.exists(det_model_dir):
            ocr_args['det_model_dir'] = det_model_dir
        if os.path.exists(rec_model_dir):
            ocr_args['rec_model_dir'] = rec_model_dir
    
    print(f"[INFO] 初始化PaddleOCR...")
    ocr = PaddleOCR(**ocr_args)
    print(f"[INFO] PaddleOCR初始化完成")
    
    # 读取所有图片
    image_files = sorted(glob.glob(os.path.join(input_dir, '*.png')))
    print(f"[INFO] 找到 {len(image_files)} 张评测图片")
    
    results = {}
    
    for img_path in tqdm(image_files, desc="推理进度"):
        # 获取图片ID（去掉路径和后缀）
        img_name = os.path.basename(img_path)
        img_id = img_name.replace('.png', '')
        
        try:
            # 执行OCR
            result = ocr.ocr(img_path, cls=False)
            
            # 解析结果
            char_list = []
            if result and result[0]:
                for line in result[0]:
                    # line格式: [bbox, (text, confidence)]
                    # bbox是4个点的多边形 [[x1,y1],[x2,y2],[x3,y3],[x4,y4]]
                    poly_points = line[0]
                    text, confidence = line[1]
                    
                    # 计算最小外接矩形 [x, y, w, h]
                    xs = [p[0] for p in poly_points]
                    ys = [p[1] for p in poly_points]
                    x = int(min(xs))
                    y = int(min(ys))
                    w = int(max(xs) - min(xs))
                    h = int(max(ys) - min(ys))
                    
                    char_list.append({
                        "bbox": [x, y, w, h],
                        "text": text
                    })
            
            results[img_id] = char_list
            
        except Exception as e:
            print(f"[WARN] 图片 {img_name} 处理失败: {e}")
            results[img_id] = []
    
    # 写入结果
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    total_chars = sum(len(v) for v in results.values())
    print(f"[INFO] 推理完成！共处理 {len(results)} 张图片，检测到 {total_chars} 个字符")
    print(f"[INFO] 结果已保存至: {output_file}")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='古文字识别推理')
    parser.add_argument('--input_dir', type=str, default='/saisdata/13/eval/images/',
                        help='输入图片目录')
    parser.add_argument('--output_file', type=str, default='/saisresult/prediction.json',
                        help='输出结果文件')
    parser.add_argument('--use_finetuned', action='store_true',
                        help='使用微调后的模型')
    args = parser.parse_args()
    
    run_inference(args.input_dir, args.output_file, args.use_finetuned)
