#!/usr/bin/env python3
"""
训练脚本 - 第二阶段：微调PaddleOCR模型
使用古文字数据微调检测和识别模型
"""

import os
import sys
import subprocess
import shutil

def prepare_paddleocr_env():
    """准备PaddleOCR训练环境"""
    os.chdir('/workspace')
    
    # 克隆PaddleOCR仓库（如果不存在）
    if not os.path.exists('/workspace/PaddleOCR'):
        print("[INFO] 克隆PaddleOCR仓库...")
        subprocess.run([
            'git', 'clone', 
            'https://github.com/PaddlePaddle/PaddleOCR.git',
            '--branch', 'release/2.8'
        ], check=True)
    else:
        print("[INFO] PaddleOCR仓库已存在")


def train_detection(data_dir, output_dir):
    """
    微调检测模型
    """
    det_data_path = os.path.join(data_dir, 'det_train.txt')
    if not os.path.exists(det_data_path):
        print(f"[WARN] 检测训练数据不存在，跳过检测模型训练: {det_data_path}")
        return None
    
    print("[INFO] 开始训练检测模型...")
    
    det_config = os.path.join('/workspace/PaddleOCR/configs/det', 
                               'det_mv3_db.yml')
    
    # 使用轻量检测配置
    config_path = '/workspace/det_train_config.yml'
    
    # 构建训练配置文件
    config_content = f"""
Global:
  use_gpu: true
  epoch_num: 10
  log_smooth_window: 20
  print_batch_step: 10
  save_model_dir: {output_dir}/det
  save_epoch_step: 3
  eval_batch_step: [0, 500]
  cal_metric_during_train: true
  pretrained_model: https://paddleocr.bj.bcebos.com/pretrained/det_mv3_db_v2.0_train.tar
  checkpoints:
  use_visualdl: false
  infer_img:
  save_res_path: {output_dir}/det/det_results.txt

Architecture:
  model_type: det
  algorithm: DB
  Transform:
  Backbone:
    name: MobileNetV3
    scale: 0.5
    model_name: large
  Neck:
    name: DBFPN
    out_channels: 256
  Head:
    name: DBHead
    k: 50

Loss:
  name: DBLoss
  balance_loss: true
  main_loss_type: DiceLoss
  alpha: 5
  beta: 10
  ohem_ratio: 3

Optimizer:
  name: Adam
  lr: 0.001

PostProcess:
  name: DBPostProcess
  thresh: 0.3
  box_thresh: 0.6
  max_candidates: 1000
  unclip_ratio: 1.5

Metric:
  name: DetMetric
  main_indicator: hmean

Train:
  dataset:
    name: SimpleDataSet
    data_dir:
    label_file_list:
      - {det_data_path}
    transforms:
      - DecodeImage:
          img_mode: BGR
          channel_first: false
      - DetLabelEncode: null
      - CopyPaste: null
      - IaaAugment:
          augmenter_args:
            - type: Fliplr
              args:
                p: 0.5
            - type: Affine
              args:
                rotate: [-10, 10]
            - type: Resize
              args:
                size: [0.5, 3]
      - EastRandomCropData:
          size: [960, 960]
          max_tries: 50
          keep_target: true
      - MakeBorderMap:
          shrink_ratio: 0.4
          thresh_min: 0.3
          thresh_max: 0.7
      - MakeShrinkMap:
          shrink_ratio: 0.4
          min_text_size: 8
      - NormalizeImage:
          scale: 1./255.
          mean: [0.485, 0.456, 0.406]
          std: [0.229, 0.224, 0.225]
          order: hwc
      - ToCHWImage: null
      - KeepKeys:
          keep_keys: ['image', 'threshold_map', 'threshold_mask', 'shrink_map', 'shrink_mask']
  loader:
    shuffle: true
    drop_last: false
    batch_size_per_card: 4
    num_workers: 2

Eval:
  dataset:
    name: SimpleDataSet
    data_dir:
    label_file_list:
      - {det_data_path}
    transforms:
      - DecodeImage:
          img_mode: BGR
          channel_first: false
      - DetLabelEncode: null
      - DetResizeForTest:
          image_shape: [736, 736]
      - NormalizeImage:
          scale: 1./255.
          mean: [0.485, 0.456, 0.406]
          std: [0.229, 0.224, 0.225]
          order: hwc
      - ToCHWImage: null
      - KeepKeys:
          keep_keys: ['image', 'shape', 'polys', 'ignore_tags']
  loader:
    shuffle: false
    drop_last: false
    batch_size_per_card: 1
    num_workers: 2
"""
    
    with open(config_path, 'w') as f:
        f.write(config_content)
    
    # 执行训练
    cmd = [
        'python3', '/workspace/PaddleOCR/tools/train.py',
        '-c', config_path
    ]
    
    print(f"[CMD] {' '.join(cmd)}")
    subprocess.run(cmd, check=True)
    
    # 寻找最佳模型
    best_model = None
    for f in sorted(os.listdir(os.path.join(output_dir, 'det'))):
        if f.startswith('best_') and f.endswith('.pdparams'):
            best_model = os.path.join(output_dir, 'det', f)
    
    print(f"[INFO] 检测模型训练完成: {best_model}")
    return best_model


def train_recognition(data_dir, output_dir, **kwargs):
    """
    微调识别模型
    """
    rec_data_path = os.path.join(data_dir, 'rec_all_train.txt')
    if not os.path.exists(rec_data_path):
        print(f"[WARN] 识别训练数据不存在，跳过: {rec_data_path}")
        return None
    
    print("[INFO] 开始训练识别模型...")
    
    # 构建字符字典
    chars = set()
    with open(rec_data_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split('\t')
            if len(parts) >= 2:
                chars.update(parts[1])
    
    # 写入字典文件
    dict_path = os.path.join(output_dir, 'dict.txt')
    # 添加PaddleOCR需要的特殊token
    special_tokens = ['blank', '---']
    sorted_chars = sorted(chars)
    with open(dict_path, 'w', encoding='utf-8') as f:
        for token in special_tokens:
            f.write(f"{token}\n")
        for c in sorted_chars:
            f.write(f"{c}\n")
    
    print(f"[INFO] 字符集大小: {len(sorted_chars)} (含特殊标记: {len(special_tokens)})")
    epochs = kwargs.get('epochs', 5)
    print(f"[INFO] 训练轮数: {epochs}")
    
    # 识别训练配置文件
    config_path = '/workspace/rec_train_config.yml'
    config_content = f"""
Global:
  use_gpu: true
  epoch_num: {epochs}
  log_smooth_window: 20
  print_batch_step: 10
  save_model_dir: {output_dir}/rec
  save_epoch_step: 5
  eval_batch_step: [0, 500]
  cal_metric_during_train: true
  pretrained_model: https://paddleocr.bj.bcebos.com/pretrained/rec_mv3_none_bilstm_ctc_v2.0_train.tar
  checkpoints:
  use_visualdl: false
  infer_img:
  save_res_path: {output_dir}/rec/rec_results.txt
  
Architecture:
  model_type: rec
  algorithm: CRNN
  Transform:
  Backbone:
    name: MobileNetV3
    scale: 0.5
    model_name: large
  Neck:
    name: RNN
    hidden_size: 96
  Head:
    name: CTCHead
    fc_decay: 0.0004

Loss:
  name: CTCLoss

PostProcess:
  name: CTCLabelDecode
  character_dict_path: {dict_path}
  use_space_char: false

Optimizer:
  name: Adam
  lr: 0.001

Metric:
  name: RecMetric
  main_indicator: acc

Train:
  dataset:
    name: SimpleDataSet
    data_dir:
    label_file_list:
      - {rec_data_path}
    transforms:
      - DecodeImage:
          img_mode: BGR
          channel_first: false
      - RecLabelEncode:
          character_dict_path: {dict_path}
          use_space_char: false
      - RecResizeImg:
          image_shape: [3, 32, 320]
      - KeepKeys:
          keep_keys: ['image', 'label', 'length']
  loader:
    shuffle: true
    drop_last: false
    batch_size_per_card: 32
    num_workers: 2

Eval:
  dataset:
    name: SimpleDataSet
    data_dir:
    label_file_list:
      - {rec_data_path}
    transforms:
      - DecodeImage:
          img_mode: BGR
          channel_first: false
      - RecLabelEncode:
          characteristic_dict_path: {dict_path}
          use_space_char: false
      - RecResizeImg:
          image_shape: [3, 32, 320]
      - KeepKeys:
          keep_keys: ['image', 'label', 'length']
  loader:
    shuffle: false
    drop_last: false
    batch_size_per_card: 32
    num_workers: 2
"""
    
    with open(config_path, 'w') as f:
        f.write(config_content)
    
    # 执行训练
    cmd = [
        'python3', '/workspace/PaddleOCR/tools/train.py',
        '-c', config_path
    ]
    
    print(f"[CMD] {' '.join(cmd)}")
    subprocess.run(cmd, check=True)
    
    # 寻找最佳模型
    best_model = None
    for f in sorted(os.listdir(os.path.join(output_dir, 'rec'))):
        if f.startswith('best_') and f.endswith('.pdparams'):
            best_model = os.path.join(output_dir, 'rec', f)
    
    print(f"[INFO] 识别模型训练完成: {best_model}")
    return best_model


def export_inference_models(output_dir):
    """
    导出PaddleOCR推理模型
    注意：如果微调效果不好，直接用预训练模型；如果微调效果好，导出微调模型
    """
    # 检测模型导出
    det_best = os.path.join(output_dir, 'det', 'best_accuracy.pdparams')
    if os.path.exists(det_best):
        print("[INFO] 导出检测推理模型...")
        os.makedirs(f'{output_dir}/inference/det', exist_ok=True)
        subprocess.run([
            'python3', '/workspace/PaddleOCR/tools/export_model.py',
            '-c', '/workspace/det_train_config.yml',
            '-o', f'Global.checkpoints={det_best}',
            f'Global.save_inference_dir={output_dir}/inference/det'
        ], check=True)
    
    # 识别模型导出
    rec_best = os.path.join(output_dir, 'rec', 'best_accuracy.pdparams')
    if os.path.exists(rec_best):
        print("[INFO] 导出识别推理模型...")
        os.makedirs(f'{output_dir}/inference/rec', exist_ok=True)
        subprocess.run([
            'python3', '/workspace/PaddleOCR/tools/export_model.py',
            '-c', '/workspace/rec_train_config.yml',
            '-o', f'Global.checkpoints={rec_best}',
            f'Global.save_inference_dir={output_dir}/inference/rec'
        ], check=True)


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='模型训练')
    parser.add_argument('--data_dir', type=str, default='/workspace/data',
                        help='预处理后的数据目录')
    parser.add_argument('--output_dir', type=str, default='/workspace/output',
                        help='模型输出目录')
    parser.add_argument('--skip_det', action='store_true',
                        help='跳过检测模型训练')
    parser.add_argument('--skip_rec', action='store_true',
                        help='跳过识别模型训练')
    parser.add_argument('--epochs', type=int, default=5,
                        help='训练轮数，默认5轮（快速微调）')
    args = parser.parse_args()
    
    os.makedirs(args.output_dir, exist_ok=True)
    
    # 准备环境
    prepare_paddleocr_env()
    
    # 训练检测模型
    if not args.skip_det:
        train_detection(args.data_dir, args.output_dir)
    
    # 训练识别模型
    if not args.skip_rec:
        train_recognition(args.data_dir, args.output_dir, epochs=args.epochs)
    
    # 导出推理模型
    export_inference_models(args.output_dir)
    
    print("[INFO] 训练完成！")
