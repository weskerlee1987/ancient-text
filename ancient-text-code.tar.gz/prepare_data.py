#!/usr/bin/env python3
"""
数据预处理：将比赛数据转换为PaddleOCR训练格式
处理训练数据中的XML标注

输入：
  /workspace/train/cross_domain/  -- 训练图片
  /workspace/train/cross_domain/Annotations/ -- XML标注
  /workspace/train/OBC/ -- 预训练单字图片

输出：
  /workspace/data/det_train.txt    -- 检测训练数据
  /workspace/data/rec_train.txt    -- 识别训练数据
  /workspace/data/rec_images/      -- 识别用裁剪图片
"""

import os
import sys
import json
import glob
import xml.etree.ElementTree as ET
from PIL import Image
from tqdm import tqdm
import shutil

def parse_xml(xml_path, img_dir):
    """
    解析XML标注文件
    返回: (img_name, img_width, img_height, objects)
    objects: [{"text": "字", "bbox": [x1,y1,x2,y2,x3,y3,x4,y4]}, ...]
    """
    tree = ET.parse(xml_path)
    root = tree.getroot()
    
    # 获取文件名
    filename = root.find('./filename').text
    
    # 获取图片尺寸
    size = root.find('./size')
    img_width = int(size.find('width').text)
    img_height = int(size.find('height').text)
    
    objects = []
    for obj in root.findall('./object'):
        text = obj.find('name').text
        # 跳过"特殊字符"占位符
        if text in ['*', '？', '□', '■']:
            continue
        
        bndbox = obj.find('bndbox')
        xmin = float(bndbox.find('xmin').text)
        ymin = float(bndbox.find('ymin').text)
        xmax = float(bndbox.find('xmax').text)
        ymax = float(bndbox.find('ymax').text)
        
        # PaddleOCR需要4个点的多边形
        polygon = [
            [xmin, ymin],  # 左上
            [xmax, ymin],  # 右上
            [xmax, ymax],  # 右下
            [xmin, ymax]   # 左下
        ]
        
        objects.append({
            "text": text,
            "bbox": polygon,
            "xmin": xmin,
            "ymin": ymin,
            "xmax": xmax,
            "ymax": ymax
        })
    
    return filename, img_width, img_height, objects


def prepare_detection_data(cross_domain_dir, output_dir):
    """
    准备检测训练数据（PaddleOCR格式）
    """
    xml_dir = os.path.join(cross_domain_dir, 'Annotations')
    img_dir = os.path.join(cross_domain_dir, 'JPEGImages')
    
    if not os.path.exists(xml_dir):
        # 尝试不同目录结构
        xml_dir = os.path.join(cross_domain_dir, 'annotations')
        img_dir = cross_domain_dir
    
    xml_files = sorted(glob.glob(os.path.join(xml_dir, '*.xml')))
    print(f"[INFO] 找到 {len(xml_files)} 个XML标注文件")
    
    det_lines = []
    skipped = 0
    
    for xml_path in tqdm(xml_files, desc="处理检测数据"):
        try:
            filename, img_w, img_h, objects = parse_xml(xml_path, img_dir)
            
            # 查找对应图片
            img_path = os.path.join(img_dir, filename)
            if not os.path.exists(img_path):
                # 尝试其他扩展名
                base = os.path.splitext(filename)[0]
                for ext in ['.png', '.jpg', '.jpeg', '.tif', '.tiff']:
                    test_path = os.path.join(img_dir, base + ext)
                    if os.path.exists(test_path):
                        img_path = test_path
                        break
            
            if not os.path.exists(img_path):
                skipped += 1
                continue
            
            # 构建PaddleOCR检测格式
            # img_path\t[{"transcription": "字", "points": [[x1,y1], ...]}, ...]
            gt_boxes = []
            for obj in objects:
                if not obj['text'].strip():
                    continue
                gt_boxes.append({
                    "transcription": obj['text'],
                    "points": obj['bbox']
                })
            
            if gt_boxes:
                line = img_path + '\t' + json.dumps(gt_boxes, ensure_ascii=False)
                det_lines.append(line)
                
        except Exception as e:
            print(f"[WARN] 解析 {xml_path} 失败: {e}")
            skipped += 1
    
    # 写入检测训练文件
    det_file = os.path.join(output_dir, 'det_train.txt')
    with open(det_file, 'w', encoding='utf-8') as f:
        f.write('\n'.join(det_lines))
    
    print(f"[INFO] 检测数据: {len(det_lines)} 条，跳过 {skipped} 个")
    return det_file


def prepare_recognition_data(cross_domain_dir, output_dir):
    """
    准备识别训练数据：从标注中裁剪出单个字符图片
    """
    xml_dir = os.path.join(cross_domain_dir, 'Annotations')
    img_dir = os.path.join(cross_domain_dir, 'JPEGImages')
    
    if not os.path.exists(xml_dir):
        xml_dir = os.path.join(cross_domain_dir, 'annotations')
        img_dir = cross_domain_dir
    
    rec_img_dir = os.path.join(output_dir, 'rec_images')
    os.makedirs(rec_img_dir, exist_ok=True)
    
    xml_files = sorted(glob.glob(os.path.join(xml_dir, '*.xml')))
    
    rec_lines = []
    char_idx = 0
    skipped = 0
    
    for xml_path in tqdm(xml_files, desc="处理识别数据"):
        try:
            filename, img_w, img_h, objects = parse_xml(xml_path, img_dir)
            
            # 查找对应图片
            img_path = os.path.join(img_dir, filename)
            if not os.path.exists(img_path):
                base = os.path.splitext(filename)[0]
                for ext in ['.png', '.jpg', '.jpeg', '.tif', '.tiff']:
                    test_path = os.path.join(img_dir, base + ext)
                    if os.path.exists(test_path):
                        img_path = test_path
                        break
            
            if not os.path.exists(img_path):
                skipped += 1
                continue
            
            # 打开图片，裁剪每个字符
            img = Image.open(img_path).convert('RGB')
            
            for obj in objects:
                text = obj['text']
                if not text.strip():
                    continue
                
                # 裁剪字符图片（加一点padding）
                x1 = max(0, int(obj['xmin']) - 2)
                y1 = max(0, int(obj['ymin']) - 2)
                x2 = min(img_w, int(obj['xmax']) + 2)
                y2 = min(img_h, int(obj['ymax']) + 2)
                
                if x2 - x1 < 5 or y2 - y1 < 5:
                    continue  # 太小的框跳过
                
                crop = img.crop((x1, y1, x2, y2))
                crop_filename = f"char_{char_idx:06d}.png"
                crop_path = os.path.join(rec_img_dir, crop_filename)
                crop.save(crop_path)
                
                rec_lines.append(f"{crop_path}\t{text}")
                char_idx += 1
                
        except Exception as e:
            skipped += 1
    
    # 写入识别训练文件
    rec_file = os.path.join(output_dir, 'rec_train.txt')
    with open(rec_file, 'w', encoding='utf-8') as f:
        f.write('\n'.join(rec_lines))
    
    print(f"[INFO] 识别数据: {char_idx} 张裁剪图片，跳过 {skipped} 个XML")
    return rec_file


def prepare_obc_pretrain(obc_dir, output_dir):
    """
    处理OBC甲骨文预训练数据（77,000张单字图片）
    目录结构: obc_dir/字/字_编号.png
    """
    if not os.path.exists(obc_dir):
        print(f"[INFO] OBC目录不存在，跳过: {obc_dir}")
        return None
    
    rec_img_dir = os.path.join(output_dir, 'rec_images')
    os.makedirs(rec_img_dir, exist_ok=True)
    
    rec_lines = []
    char_idx = 0
    
    # 遍历所有子目录（每个子目录名就是字符）
    subdirs = sorted([d for d in os.listdir(obc_dir) 
                     if os.path.isdir(os.path.join(obc_dir, d))])
    
    print(f"[INFO] OBC目录: {len(subdirs)} 个字符类别")
    
    for subdir in tqdm(subdirs, desc="处理OBC数据"):
        subdir_path = os.path.join(obc_dir, subdir)
        image_files = sorted(glob.glob(os.path.join(subdir_path, '*')))
        
        # 每个字符类别最多取50张（足够训练用）
        for img_path in image_files[:50]:
            ext = os.path.splitext(img_path)[1].lower()
            if ext not in ['.png', '.jpg', '.jpeg', '.bmp', '.tif']:
                continue
            
            # 复制到统一目录
            crop_filename = f"obc_{char_idx:06d}{ext}"
            crop_path = os.path.join(rec_img_dir, crop_filename)
            shutil.copy2(img_path, crop_path)
            
            rec_lines.append(f"{crop_path}\t{subdir}")
            char_idx += 1
    
    obc_rec_file = os.path.join(output_dir, 'rec_obc_train.txt')
    with open(obc_rec_file, 'w', encoding='utf-8') as f:
        f.write('\n'.join(rec_lines))
    
    print(f"[INFO] OBC数据: {char_idx} 张图片，{len(subdirs)} 个字符类别")
    return obc_rec_file


def merge_rec_data(output_dir):
    """
    合并所有识别训练数据
    """
    all_lines = []
    
    for fname in ['rec_train.txt', 'rec_obc_train.txt']:
        fpath = os.path.join(output_dir, fname)
        if os.path.exists(fpath):
            with open(fpath, 'r', encoding='utf-8') as f:
                lines = [l.strip() for l in f if l.strip()]
                all_lines.extend(lines)
    
    # 合并并shuffle
    import random
    random.shuffle(all_lines)
    
    merged_file = os.path.join(output_dir, 'rec_all_train.txt')
    with open(merged_file, 'w', encoding='utf-8') as f:
        f.write('\n'.join(all_lines))
    
    print(f"[INFO] 合并识别数据: {len(all_lines)} 条")
    return merged_file


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='数据预处理')
    parser.add_argument('--train_dir', type=str, required=True,
                        help='训练数据根目录 (train.tar解压后)')
    parser.add_argument('--output_dir', type=str, default='/workspace/data',
                        help='输出目录')
    args = parser.parse_args()
    
    os.makedirs(args.output_dir, exist_ok=True)
    
    # 1. 处理跨域训练数据
    cross_domain_dir = os.path.join(args.train_dir, 'cross_domain')
    if os.path.exists(cross_domain_dir):
        prepare_detection_data(cross_domain_dir, args.output_dir)
        prepare_recognition_data(cross_domain_dir, args.output_dir)
    
    # 2. 处理OBC预训练数据
    obc_dir = os.path.join(args.train_dir, 'OBC')
    prepare_obc_pretrain(obc_dir, args.output_dir)
    
    # 3. 合并识别数据
    merge_rec_data(args.output_dir)
    
    print("[INFO] 数据预处理完成！")
    print(f"  - 检测数据: {args.output_dir}/det_train.txt")
    print(f"  - 识别数据: {args.output_dir}/rec_all_train.txt")
