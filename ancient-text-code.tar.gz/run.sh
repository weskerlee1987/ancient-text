#!/bin/bash
cd /workspace
python3 /workspace/infer.py --use_finetuned
